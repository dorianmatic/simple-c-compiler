def is_non_terminal(symbol):
    return symbol.startswith('<') and symbol.endswith('>')